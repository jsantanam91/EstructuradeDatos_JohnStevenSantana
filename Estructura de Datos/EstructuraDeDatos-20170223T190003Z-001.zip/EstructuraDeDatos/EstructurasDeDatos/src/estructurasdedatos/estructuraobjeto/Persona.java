/*
 * Fecha:22/2/2017
 * Descripción: Clase Persona, primera estructura de datos, una clase es una plantilla 
                de donde puedo instanciar objetosde tipo Persona. Una instancia es una
                variable o un lugar en la memoria del computador y almacena los atributos y
                metodos que tiene el objeto.
 * Autor: John Steven Santana Muñoz
 */
//Definiendo el paquete donde esta la clase.
package estructurasdedatos.estructuraobjeto;

/**
 *
 * @author utp
 */
//La firma de la clase
public class Persona {
    
    private String nombre;
    private int cedula;
    private String direccion;
    private String telefono;

    /*
     * @return the Nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        //Codifico las reglas de negocio para cambiar un atributo
        this.nombre = Nombre;
    }

    /**
     * @return the Cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @return the Dirección
     */
    public String getDirección() {
        return direccion;
    }

    /**
     * @param Direccion the Dirección to set
     */
    public void setDirección(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the Telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param Telefono the Telefono to set
     */

}
