/*
 * Esta clase es la clase principal generada automaticamente al iniciar un proyecto desde netbeans
 */
package estructurasdedatos;

import estructurasdedatos.estructuraobjeto.Persona;

/**
 *
 * @author utp
 */
public class EstructurasDeDatos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Persona juan = new Persona();
        
        juan.setnombre("Juan Perez");

      
        System.out.println(" Nombre: " + juan.getNombre() + " Direccion: " +  );

        System.out.println("Hola Mundo");
        

    }

}
